@echo off
jre\bin\java.exe -Xmx1G -cp minecraft.jar -Djava.library.path=.\natives\ org.mcphackers.launchwrapper.Launch --username gfwr7a --gameDir .\Game\
pause